package first;

import java.util.Calendar;
import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FirstSpring {

	public static void main(String[] args) {
		String config = 
				"applicationContext.xml";
		/*
		 * ApplicationContext:是一个接口。
		 * ClassPathXmlApplicationContext:
		 * 是实现了上述接口的具体类。
		 * 注：
		 * 	该类依据类路径查找配置文件,然后
		 * 启动Spring容器。
		 */
		ApplicationContext ac =
		new ClassPathXmlApplicationContext(
				config);
		
		/*
		 * getBean方法：第一个参数是bean的id,
		 * 第二个参数是class对象。
		 */
		Apple a1 = ac.getBean("a1",
				Apple.class);
		System.out.println("a1:" + a1);
		
		
		Date date1 = 
				ac.getBean("date1",Date.class);
		System.out.println("date1:" + date1);
		
		Calendar c1 = 
				ac.getBean("c1",
						Calendar.class);
		System.out.println("c1:" + c1);
		
		Date t1 = 
				ac.getBean("t1",Date.class);
		System.out.println("t1:" + t1);
		
		
		
		
		
	}

}
