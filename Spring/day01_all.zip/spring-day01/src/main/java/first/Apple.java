package first;

public class Apple {

	public Apple() {
		System.out.println("Apple()");
	}
	
}
