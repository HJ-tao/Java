package basic;

public class Order {

	public Order() {
		System.out.println("Order()");
	}
	
}
