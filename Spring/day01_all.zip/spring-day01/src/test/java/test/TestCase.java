package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import basic.MessageService;
import basic.Order;
import ioc.A;

public class TestCase {
	@Test
	//测试　作用域
	public void test1(){
		String config = 
				"basic.xml";
		ApplicationContext ac =
		new ClassPathXmlApplicationContext(
				config);
		Order order1 = 
				ac.getBean("order1",
						Order.class);
		Order order2 = 
				ac.getBean("order1",
						Order.class);
		System.out.println(order1 == order2);
		
	}
	
	@Test
	//测试　初始化方法
	public void test2(){
		String config = 
				"basic.xml";
		//启动Spring容器
		/*
		 * ApplicationContext是一个接口，
		 * 并没有提供关闭容器的方法(close),
		 * 需要使用AbstractApplicationContext。
		 */
		AbstractApplicationContext ac =
		new ClassPathXmlApplicationContext(
				config);
		MessageService ms1 = 
			ac.getBean("ms1",
					MessageService.class);
		ms1.sendMsg();
		//关闭Spring容器
		ac.close();
	}
	
	@Test
	//测试　延迟加载
	public void test3(){
		String config = 
				"basic.xml";
		ApplicationContext ac =
		new ClassPathXmlApplicationContext(
				config);	
	}
	
	
	@Test
	//测试　　set方法注入
	public void test4(){
		String config = 
				"ioc.xml";
		ApplicationContext ac =
		new ClassPathXmlApplicationContext(
				config);
		A a1 = 
				ac.getBean("a1",A.class);
		a1.execute();
	}
	
	
	
	
	
	
	
}
