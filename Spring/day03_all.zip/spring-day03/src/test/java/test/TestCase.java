package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import annotations.Apple;
import annotations.Leader;
import annotations.Manager;
import annotations.Restaurant;
import annotations.Student;

public class TestCase {
	@Test
	public void test1(){
		String config = "annotations.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		Apple apple = 
				ac.getBean("a1",
						Apple.class);
		System.out.println(apple);
	}
	
	@Test
	public void test2(){
		String config = "annotations.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		Apple apple = 
				ac.getBean("a1",
						Apple.class);
		Apple apple2 = 
				ac.getBean("a1",
						Apple.class);
		System.out.println(apple == apple2);
	}
	
	@Test
	public void test3(){
		String config = "annotations.xml";
		AbstractApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		Apple a1 = 
				ac.getBean("a1",Apple.class);
		System.out.println(a1);
		ac.close();
	}
	
	@Test
	public void test4(){
		String config = "annotations.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);	
		
	}
	
	@Test
	//测试　@Autowired和@Qualifier
	public void test5(){
		String config = "annotations.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		Restaurant rest = 
				ac.getBean("rest",
						Restaurant.class);
		System.out.println(rest);
		Manager mg = 
				ac.getBean("mg",Manager.class);
		System.out.println(mg);
	}
	
	@Test
	//测试　@Resource
	public void test6(){
		String config = "annotations.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		Leader ld = 
				ac.getBean("ld",Leader.class);
		System.out.println(ld);
	}
	
	@Test
	//测试　@Value
	public void test7(){
		String config = "annotations.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		Student stu = 
				ac.getBean("stu",Student.class);
		System.out.println(stu);
	}
	
	
	
	
}





