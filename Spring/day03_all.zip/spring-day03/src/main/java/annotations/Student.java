package annotations;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("stu")
public class Student {
	
	@Value("李白")
	private String name;
	@Value("22")
	private int age;
	@Value("#{config.pageSize}")
	private String pageSize;
	
	public Student() {
		System.out.println("Student()");
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + ", pageSize=" + pageSize + "]";
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}
	
	
	
}


