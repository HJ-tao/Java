package annotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("mg")
public class Manager {
	private Waiter wt;
	
	
	@Autowired
	public Manager(
			@Qualifier("wt") Waiter wt) {
		System.out.println("Manager(wt)");
		this.wt = wt;
	}

	@Override
	public String toString() {
		return "Manager [wt=" + wt + "]";
	}
	
	public Manager() {
		System.out.println("Manager()");
	}
	
}
