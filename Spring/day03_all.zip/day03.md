# 1. 组件扫描
## (1)什么是组件扫描?
	Spring容器会检查base-package指定的
	包及其子包下面的所有的类，如果该类
	前面有一些特定的注解（比如@Component）,
	则容器会将这个类纳入容器进行管理
	（相当于配置文件当中有一个bean元素）。
## (2)如何进行组件扫描?
	step1.在类前面添加一些特定的注解，比如@Component。
![](s1.png)
	
	step2.在配置文件当中，配置组件扫描。
![](s2.png)

## (2)几个相关注解
	@Scope  用来指定作用域，比如  @Scope("prototype")
	@Lazy   用来指定是否延迟加载　，比如　@Lazy(true)
	@PostConstruct 指定初始化方法 (该注解来自于sun)。
	@PreDestroy   指定销毁方法(该注解来自于sun)。

## (3)依赖注入相关的注解
	@Autowired和@Qualifier
	a.支持set方法注入和构造器注入。
	b.可以将该注解添加到set方法或者构造器前面，其中,
	@Qualifier用来指定被注入的bean的id(默认会按照byType)。
	c.也可以直接将该注解添加到属性前。
![](s3.png)
![](s4.png)		

	@Resource 
	a.只支持set方法注入。
	b.该注解来自于sun。
![](s5.png)

## (4)Value注解
![](s6.png)

# 2. SpringMVC
## (1)什么是SpringMVC?
	用来简化基于MVC架构的web应用程序开发的框架。
	注：
		SpringMVC是Spring框架的一部分。
##　(2)核心组件（五大组件）
	1)DispatcherServlet  前端控制器
	2)HandlerMapping	映射处理器
	3)Controller	处理器
	4)ModelAndView	模型和视图
	5)ViewResolver	视图解析器
	**相互关系:**
	a.请求先发送给DispatcherServlet,DispatcherServlet收到请求
	之后，依据HandlerMapping的配置调用对应的Controller来处理。
	b.Controller将处理结果封装成ModelAndView,然后返回给
	DispatcherServlet。
	c.DispatcherServlet依据ViewResolver的解析，调用对应的
	jsp生成页面。
![](springmvc.png)

## (3)编程步骤
	step1.导包。
		spring-webmvc
	step2.添加spring配置文件。
	step3.配置DispatcherServlet。(web.xml)
	step4.写Controller。
	step5.写jsp。
	step6.配置HandlerMapping和ViewResolver。
![](hello.png)	
	
	
			


	
	
			