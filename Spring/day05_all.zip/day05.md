# 1. 系统分层　（扩展）
## (1)如何分层?
	表示层: 数据展现/操作界面，请求分发。
	业务层(服务层): 业务逻辑处理。
	数据访问层(持久层):数据访问逻辑。
	注:
		1)表示层调用业务层，业务层调用数据访问层。
		2)上一层应该通过接口来调用下一层提高的服务。
			这样下一层的实现发生改变，不影响上一层。
## (2)登录案例
![](layer.png)
![](login.png)

# 2. 表单包含有中文参数值，如何处理?
## (1)为什么会有乱码?
	表单提交时，浏览器会对中文参数值使用打开该表单所在页面时的
	字符集来编码。比如使用"utf-8"来编码。
	服务器端默认使用"iso-8859-1"来解码。
	所以会产生乱码。
## (2)如何解决?
	配置springmvc提供的过滤器(CharacterEncodingFilter)。
	注意：
	a.表单提交方式必须设置为"Post"
	b.页面编码与初始化参数设置的编码要一致。
	
	

	练习：
	　完成资费列表 (要求系统分层，表示层使用springmvc)
	提示:
	step1. Cost实体类　（与Cost表对应）
	step2. CostDAO接口
			public List<Cost> findAll();	
	step3. CostDAOJdbc类　（实现上述接口）	
	step4. 测试数据访问层(即测试CostDAO)
	step5. CostService接口
			public List<Cost> findAll();
	step6. CostServiceImpl类。
	step7.　测试业务层 (即测试CostService)
	step8. CostController。（将请求分发给CostService来处理）
	step9. fee_list.jsp。(显示资费列表)




