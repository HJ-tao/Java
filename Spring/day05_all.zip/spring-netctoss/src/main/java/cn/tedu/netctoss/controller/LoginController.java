package cn.tedu.netctoss.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.tedu.netctoss.entity.Admin;
import cn.tedu.netctoss.service.AppException;
import cn.tedu.netctoss.service.LoginService;

@Controller
public class LoginController {
	
	@Resource(name="loginService")
	private LoginService ls;
	
	@RequestMapping("/toLogin.do")
	public String toLogin(){
		System.out.println("toLogin()");
		return "login";
	}
	
	@RequestMapping("/login.do")
	public String login(
			HttpServletRequest request){
		System.out.println("login()");
		String adminCode = 
			request.getParameter("adminCode");
		String pwd = 
			request.getParameter("pwd");
		System.out.println("adminCode:"
			+ adminCode);
		
		//将请求分发给业务层对象来处理
		/*
		 * 表示层需要处理业务层对象所抛出的异常
		 */
		try{
			Admin admin = ls.checkLogin(
					adminCode, pwd);
			
		}catch(Exception e){
			e.printStackTrace();
			if(e instanceof AppException){
				//应用异常，
				//明确提示用户采取正确的操作
				request.setAttribute(
						"login_failed", 
						e.getMessage());
				return "login";
			}else{
				//系统异常
				//提示用户稍后重试
				return "error";
			}
		}
		//登录成功,重定向到首页
		return "redirect:toIndex.do";
	}
	
	@RequestMapping("/toIndex.do")
	public String toIndex(){
		return "index";
	}
}




