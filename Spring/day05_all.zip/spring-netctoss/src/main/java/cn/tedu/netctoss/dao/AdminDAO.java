package cn.tedu.netctoss.dao;

import cn.tedu.netctoss.entity.Admin;

/**
 *  数据访问层接口
 *		接口不应该涉及任何具体的实现。
 */
public interface AdminDAO {
	public Admin findByCode(String code);
}




