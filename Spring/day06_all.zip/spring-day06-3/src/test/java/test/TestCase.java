package test;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.EmployeeDAO;
import entity.Employee;

public class TestCase {
	private EmployeeDAO dao;
	
	@Before
	/*
	 * 测试方法运行之前，会先执行
	 * @Before修饰的方法。
	 */
	public void init(){
		String config = "spring-jdbc.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		dao = ac.getBean("empDAO",
					EmployeeDAO.class);	
	}
	
	@Test
	public void test1() throws SQLException{
		String config = "spring-jdbc.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		DataSource ds = 
			ac.getBean("ds",DataSource.class);
		System.out.println(
				ds.getConnection());
	}
	
	@Test
	public void test2(){
		Employee e = new Employee();
		e.setName("楚乔");
		e.setSalary(1000.0);
		e.setAge(22);
		dao.save(e);
	}
	
	@Test
	public void test3(){
		List<Employee> employees = 
			dao.findAll();
		System.out.println(employees);
	}
	
	@Test
	public void test4(){
		Employee e = 
				dao.findById(1);
		System.out.println(e);
	}
	
	
	
	
	
	
	
	
	
	
	
}
