package interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

public class SomeInterceptor implements
	HandlerInterceptor{

	/**
	 * 请求处理完毕，最后执行的方法。
	 * (了解)
	 * 	arg3:处理器所抛出的异常。
	 */
	public void afterCompletion(
			HttpServletRequest arg0, 
			HttpServletResponse arg1, 
			Object arg2, Exception arg3)
			throws Exception {
		System.out.println("afterCompletion()");
	}

	/**
	 * 处理器(Controller)方法已经执行完毕，
	 * 正准备将处理结果(ModelAndView)返回
	 * 给DispatcherServlet之前，执行postHandle
	 * 方法。
	 * 注：
	 * 	可以在该方法里面，修改处理结果。
	 */
	public void postHandle(
			HttpServletRequest arg0, 
			HttpServletResponse arg1, 
			Object arg2, ModelAndView arg3)
			throws Exception {
		System.out.println("postHandle()");
	}

	/**
	 * DispatcherServlet会先调用拦截器的
	 * preHandle方法，如果该方法返回值为
	 * true,则继续向后调用；否则，中断请求
	 * （不再向后调用）。
	 * (了解)
	 * 	arg2:是一个描述处理器方法的对象。
	 */
	public boolean preHandle(
			HttpServletRequest arg0,
			HttpServletResponse arg1, 
			Object arg2) throws Exception {
		System.out.println("preHandle()");
		return true;
	}
	
	
	

}


