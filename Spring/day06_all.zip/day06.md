
#　1.拦截器
## (1)什么是拦截器?
	DispatcherServlet收到请求之后，如果有拦截器，则先执行
	拦截器的方法，然后再执行处理器的方法。
	注：
		过滤器属于Servlet规范，而拦截器属于Spring框架。
## (2)如何写拦截器?
	step1. 写一个java类，实现HandlerInterceptor接口。
	step2. 在拦截器方法里面，实现拦截处理逻辑。
	step3.　配置拦截器。
![](s1.png)

# 2.异常处理 
	注：将异常抛给springmvc框架，由框架来处理异常。
	(1)方式一　　配置简单异常处理器。
	step1.配置简单异常处理器。
![](s2.png)

	step2.添加异常处理页面。
	(2)方式二　使用@ExceptionHandler注解。
	step1.　添加一个异常处理方法，该方法前面要添加
			@ExceptionHandler注解。
![](s3.png)

	step2.添加异常处理页面。

# 2. SpringJdbc
## (1)SpringJdbc是什么?
	spring对jdbc的封装。
	使用SpringJdbc访问数据库，不用考虑如何获取连接、关闭连接等等
	繁琐的操作。
## (2)编程步骤
	step1.导包。
		spring-webmvc,spring-jdbc,
		ojdbc,dbcp,junit。
	step2.添加Spring配置文件。
	step3.配置JdbcTemplate。　
![](s4.png)
　
	step4.调用JdbcTemplate提供的方法。
		注：通常将JdbcTemplate注入到DAO。	
![](s5.png)	

	create table t_emp(
		id number(8) primary key,
		name varchar2(50),
		salary number(8,2),
		age number(3)
	);
	create sequence t_emp_seq;
	

	

			
		
	

	

	
	