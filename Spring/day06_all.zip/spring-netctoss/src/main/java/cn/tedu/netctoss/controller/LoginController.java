package cn.tedu.netctoss.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.tedu.netctoss.entity.Admin;
import cn.tedu.netctoss.service.AppException;
import cn.tedu.netctoss.service.LoginService;

@Controller
public class LoginController {
	
	@Resource(name="loginService")
	private LoginService ls;
	
	@RequestMapping("/toLogin.do")
	public String toLogin(){
		System.out.println("toLogin()");
		return "login";
	}
	
	@ExceptionHandler
	public String handleEx(Exception e,
			HttpServletRequest request){
		System.out.println("handleEx()");
		if(e instanceof AppException){
			//应用异常
			request.setAttribute(
					"login_failed",
					e.getMessage());
			return "login";
		}
		//系统异常
		return "error";
	}
	
	@RequestMapping("/login.do")
	public String login(
			HttpServletRequest request,
			HttpSession session){
		System.out.println("login()");
		String adminCode = 
			request.getParameter("adminCode");
		String pwd = 
			request.getParameter("pwd");
		System.out.println("adminCode:"
			+ adminCode);
		
		//将请求分发给业务层对象来处理
		/*
		 * 表示层需要处理业务层对象所抛出的异常
		 */
			Admin admin = ls.checkLogin(
					adminCode, pwd);
			//登录成功之后，绑订一些数据到
			//session,用于session验证。
			session.setAttribute("admin",
					admin);
		
		//登录成功,重定向到首页
		return "redirect:toIndex.do";
	}
	
	@RequestMapping("/toIndex.do")
	public String toIndex(){
		return "index";
	}
}




