package test;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import org.junit.Test;

public class TestCase2 {
	@Test
	public void test1() throws UnsupportedEncodingException{
		String str = "李白";
		String str2 = 
				URLEncoder.encode(str,
						"utf-8");
		System.out.println(str2);
		String str3 = 
				URLDecoder.decode(str2,
						"iso-8859-1");
		System.out.println(str3);
		
	}
}
