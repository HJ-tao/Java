package test;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.tedu.netctoss.dao.AdminDAO;
import cn.tedu.netctoss.entity.Admin;
import cn.tedu.netctoss.service.LoginService;

public class TestCase {
	@Test
	//测试　连接池
	public void test1() throws SQLException{
		String config = "spring-mvc.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		DataSource ds = 
			ac.getBean("ds",DataSource.class);
		System.out.println(
				ds.getConnection());
	}
	
	@Test
	//测试　　数据访问层
	public void test2(){
		String config = "spring-mvc.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		AdminDAO dao = 
				ac.getBean("adminDAO",
						AdminDAO.class);
		Admin admin = 
				dao.findByCode("caocao");
		System.out.println(admin);
	}
	
	@Test
	//测试　业务层
	public void test3(){
		String config = "spring-mvc.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		LoginService ls = 
			ac.getBean("loginService",
					LoginService.class);
		Admin admin = 
				ls.checkLogin("caocao", 
						"1234");
		System.out.println(admin);
	}
	
}


