package entity;

public class Emp {
	private Integer empId;
	private String ename;
	private Double salary;
	private Integer age;
	
	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", ename=" + ename + ", salary=" + salary + ", age=" + age + "]";
	}
	
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	
	
}
