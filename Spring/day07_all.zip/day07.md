# 1. MyBatis
## (1)MyBatis是什么?
	开源的持久层框架。
	注：底层仍然是jdbc。　　
	(了解)
	jdbc   优点：速度最快　　缺点:繁琐
	hibernate 优点:不用写sql,代码简洁　　
				缺点：速度慢，需要优化繁杂的sql
	mybatis  优点：代码简洁，易掌握　性能速中　需要写sql
## (2)编程步骤
	step1.导包。
		mybatis,ojdbc,junit
	step2.添加配置文件。
	step3.实体类。
		注：属性名必须等于表的字段名。（大小写可以忽略）
	step4.添加映射文件。
		注：主要是sql语句。
	step5.调用mybatis提供的api访问数据库。
		注: SqlSession提供的方法。
## (3)基本原理
![](mybatis.png)	

## (4)返回Map类型的结果
	mybatis会将查询结果分两步处理：
	step1. 将记录中的数据添加到一个对应的Map对象里面
	（以字段名作为key,以字段值作为value）。
	step2. 再将Map对象中的数据添加到对应的实体对象里面。
![](mybatis2.png)

## (5)解决字段名与实体类属性名不一致的情况。
	方式一　　使用别名，比如
	SELECT id empId,name ename……
	方式二　　使用resultMap。
![](s1.png)	

## (6)mapper映射器
	1)mapper映射器是什么?
	符合映射文件要求的接口。
	要求如下:
		a.方法名要与sqlId一致。
		b.方法的返回类型要与resultType一致。
		c.方法的参数类型要与parameterType一致。
		d.映射文件的namespace必须等于接口的完整的名字。
	注：
		mybatis会生成符合该接口(mapper映射器)要求的对象。
	2)如何使用mapper映射器?
	 step1.按照要求写好接口。
	 step2.调用SqlSession提供的getMapper方法来获得接口实现。
		
	
	
