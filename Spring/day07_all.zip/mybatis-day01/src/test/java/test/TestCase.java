package test;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import entity.Emp;
import entity.Employee;

public class TestCase {
	private SqlSession session;
	@Before
	public void init(){
		
		String config = "SqlMapConfig.xml";
		SqlSessionFactoryBuilder ssfb = 
			new SqlSessionFactoryBuilder();
		SqlSessionFactory ssf = 
			ssfb.build(TestCase.class
			.getClassLoader()
			.getResourceAsStream(config));
		
		session = ssf.openSession();
	}
	
	@Test
	public void test1(){
		
		/*
		 * SqlSession提供了执行sql的各种方法，
		 * 一般第一个参数是要执行的sql的id。
		 * 如果是添加,删除及修改操作，要提交
		 * 事务。
		 * 方法执行完毕，要关闭SqlSession。
		 */
		Employee e = new Employee();
		e.setName("龙儿");
		e.setSalary(2000.0);
		e.setAge(22);
		
		session.insert("test.save", e);
		session.commit();
		session.close();
	}
	
	@Test
	public void test2(){
		List<Employee> employees = 
				session.selectList(
						"test.findAll");
		System.out.println(employees);
		session.close();
	}
	
	@Test
	public void test3(){
		Employee e = 
				session.selectOne(
						"test.findById", 21);
		System.out.println(e);
		session.close();
	}
	
	@Test
	public void test4(){
		Employee e = 
				session.selectOne(
						"test.findById", 21);
		e.setSalary(e.getSalary() + 1000);
		e.setAge(e.getAge() + 1);
		session.update("test.modify", e);
		session.commit();
		session.close();
	}
	
	@Test
	public void test5(){
		session.delete("test.delete", 21);
		session.commit();
		session.close();
	}
	
	@Test
	public void test6(){
		Map map = 
			session.selectOne(
					"test.findById2",23);
		System.out.println(
				map.get("NAME"));
		session.close();
	}
	
	@Test
	public void test7(){
		Emp emp = 
				session.selectOne
				("test.findById3",23);
		System.out.println(emp);
		session.close();
	}
	
	
	
	
	
	
	
	
}





