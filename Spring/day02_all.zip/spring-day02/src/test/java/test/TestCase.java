package test;

import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import auto.Manager;
import ioc.Restaurant;
import value.Student;
import value.Teacher;

public class TestCase {
	@Test
	//测试　构造器注入
	public void test1(){
		String config = "ioc.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		Restaurant rest1 = 
			ac.getBean("rest1",Restaurant.class);
		System.out.println(rest1);
		
	}
	
	@Test
	//测试　自动装配
	public void test2(){
		String config = "auto.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);	
		Manager mg = 
				ac.getBean("mg",Manager.class);
		System.out.println(mg);
	}
	
	@Test
	public void test3(){
		String config = "value.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);	
		Student stu1 = 
				ac.getBean("stu1",Student.class);
		System.out.println(stu1);
	}
	
	@Test
	//测试　以引用的方式注入集合类型的值
	public void test4(){
		String config = "value.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);	
		Student stu2 = 
				ac.getBean("stu2",Student.class);
		System.out.println(stu2);
	}
	
	@Test
	public void test5(){
		String config = "value.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		Properties props = 
			ac.getBean("config",
					Properties.class);
		System.out.println(props);
	}
	
	@Test
	//测试　spring表达式
	public void test6(){
		String config = "value.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);	
		Teacher t1 = 
				ac.getBean("t1",Teacher.class);
		System.out.println(t1);
	}
	
	@Test
	//测试　连接池
	public void test7() throws SQLException{
		String config = "value.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		/*
		 * javax.sql.DataSource是一个接口，
		 * BasicDataSource实现了上述接口。
		 */
		
		DataSource ds = 
				ac.getBean("ds",
						DataSource.class);
		System.out.println(
				ds.getConnection());
		
		
		
		
	}
	
}




