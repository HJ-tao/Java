package controller;
/**
 * 用于封装请求参数。要求：
 * 	a.属性名要与请求参数名一致。
 * 	b.提供相应的set/get方法。
 *	注：
 *		Spring会帮我们做类型转换。
 */
public class AdminParam {
	private String adminCode;
	private String pwd;
		
	public String getAdminCode() {
		return adminCode;
	}
	public void setAdminCode(String adminCode) {
		this.adminCode = adminCode;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
}
