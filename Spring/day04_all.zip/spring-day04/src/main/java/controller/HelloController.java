package controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	@RequestMapping("/hello.do")
	public String hello(){
		System.out.println("hello()");
		//返回视图名
		return "hello";
	}
	
	@RequestMapping("/toLogin.do")
	public String toLogin(){
		System.out.println("toLogin()");
		return "login";
	}
	
	@RequestMapping("/login.do")
	/*
	 * (了解)
	 * DispatcherServlet在调用Controller
	 * 的方法之前，会利用java反射机制分析
	 * 方法的结构，然后将需要的对象作为参数
	 * 传递过来（并如将request对象作为参数
	 * 传递过来）。
	 */
	public String login(
			HttpServletRequest request){
		System.out.println("login()");
		String adminCode = 
			request.getParameter("adminCode");
		String pwd = 
			request.getParameter("pwd");
		System.out.println("adminCode:" 
			+ adminCode + " pwd:" + pwd);
		return "index";
	}
	
	@RequestMapping("/login2.do")
	/*
	 * 形参名要与请求参数名一致。
	 * 如果不一致，使用@RequestParam。
	 */
	public String login2(String adminCode,
			@RequestParam("pwd") 
			String password){
		System.out.println("login()");
		System.out.println("adminCode:" 
				+ adminCode + " pwd:" 
				+ password);
		return "index";
	}
	
	@RequestMapping("/login3.do")
	public String login3(AdminParam ap){
		System.out.println("login3()");
		System.out.println("adminCode:" 
		+ ap.getAdminCode() + " pwd:"
				+ ap.getPwd());
		return "index";
	}
	
	@RequestMapping("/login4.do")
	public String login4(AdminParam ap,
			HttpServletRequest request){
		System.out.println("login4()");
		
		request.setAttribute("adminCode",
				ap.getAdminCode());
		/*
		 * DispatcherServlet默认会使用转发
		 */
		return "index";
	}
	
	@RequestMapping("/login5.do")
	/*
	 * (了解)
	 * 	DispatcherServlet会从ModelAndView
	 * 对象当中将数据（即Map）取出来，然后
	 * 将Map中的数据绑订到request(以key作为
	 * 绑订名，以value作为绑订值)。
	 */
	public ModelAndView login5(
			AdminParam ap){
		System.out.println("login5()");
		//先将数据添加到ModelAndView
		Map<String,Object> data = 
			new HashMap<String,Object>();
		data.put("adminCode", 
				ap.getAdminCode());
		ModelAndView mav  = 
				new ModelAndView(
						"index",data);
		//然后返回ModelAndView
		return mav;
	}
	
	@RequestMapping("/login6.do")
	/*
	 * (了解)
	 * DispatcherServlet会从ModelMap
	 * 中取出数据，然后绑订到request。
	 */
	public String login6(AdminParam ap,
			ModelMap mm){
		System.out.println("login6()");
		
		mm.addAttribute("adminCode",
				ap.getAdminCode());
		
		return "index";
	}
	
	@RequestMapping("/login7.do")
	public String login7(AdminParam ap,
			HttpSession session){
		System.out.println("login7()");
		
		session.setAttribute("adminCode",
				ap.getAdminCode());
		//重定向
		return "redirect:toIndex.do";
	}
	
	@RequestMapping("/toIndex.do")
	public String toIndex(){
		System.out.println("toIndex()");
		return "index";
	}
	
	
	
	
	
}




