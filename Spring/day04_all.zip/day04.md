# 1.基于注解的SpringMVC
## (1)编程步骤
	step1.导包。 spring-webmvc
	step2.添加Spring配置文件。
	step3.配置DispatcherServlet。
	step4.写Controller。
		a.不用实现Controller接口。
		b.可以添加多个方法。（一个处理器可以处理多种请求）
		c.方法名不做要求，返回值可以是String,也可以是ModelAndView。
		d.添加@Controller注解到类名前。(组件扫描)
		e.在类名前或者方法前添加@RequestMapping。
		（代替HandlerMapping）
	step5.写jsp。
	step6.配置ViewResolver,配置组件扫描，配置mvc注解扫描。

## (2)读取请求参数值	
	1)方式一　通过request。
	2)方式二　通过@RequestParam。
	3)方式三　通过javabean。	

## (3)向页面传值
	1)方式一　将数据绑订到request。
	2)方式二　返回ModelAndView。
	3)方式三　将数据绑订到ModelMap。
	4)方式四　将数据绑订到session。

##　(4)重定向
	1)情形一：　如果方法的返回值是String
		在重定向地址前添加"redirect:"。
		比如　
			return "redirect:toIndex.do"
	2)情形二： 如果方法的返回值是ModelAndView
		RedirectView rv = new RedirectView("toIndex.do");
		ModelAndView mav = new ModelAndView(rv);
		return mav;

# 2. 系统分层　（扩展）
## (1)如何分层?
	表示层: 数据展现/操作界面，请求分发。
	业务层(服务层): 业务逻辑处理。
	数据访问层(持久层):数据访问逻辑。
	注:
		1)表示层调用业务层，业务层调用数据访问层。
		2)上一层应该通过接口来调用下一层提高的服务。
			这样下一层的实现发生改变，不影响上一层。
## (2)案例
![](layer.png)
	