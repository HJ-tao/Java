package cn.tedu.netctoss.dao;

import cn.tedu.netctoss.entity.Admin;
/**
 * 数据访问层实现
 *
 */
public class AdminDAOJdbcImpl 
	implements AdminDAO{

	public Admin findByCode(String code) {
		
		return null;
	}

}
