package cn.tedu.netctoss.dao;

import cn.tedu.netctoss.entity.Admin;

/**
 *  数据访问层接口
 *
 */
public interface AdminDAO {
	public Admin findByCode(String code);
}


