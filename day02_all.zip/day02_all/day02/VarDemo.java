package day02;
//变量的演示
public class VarDemo {
	public static void main(String[] args) {
		/*
		 * 1)题目不用抄  2)注释不用写  3)有错必须改
		 * 变量的练习:
		 * 1)声明一个整型的变量，名为a
		 *   声明三个整型的变量，名为b,c,d
		 * 2)声明整型变量e并赋值为250
		 *   声明整型变量f，
		 *     给变量f赋值为250
		 * 3)声明整型变量g并赋值为5，
		 *     声明整型变量h并赋值为g+10，输出h
		 *   声明整型变量i并赋值为3.14-----???
		 *   输出m的值--------------------???
		 *   声明整型变量m，输出m的值------???
		 * 4)声明几个正确的和几个错误的变量
		 */
		
		
		
		
		
		/*
		//4.变量的命名:
		int a1,a_5$,_5b,_$,$4;
		//int a*b; //编译错误，不能包含*号等特殊字符
		//int 1a; //编译错误，不能以数字开头
		int a = 5;
		//System.out.println(A); //编译错误，严格区分大小写
		//int class; //编译错误，不能使用关键字
		int 年龄; //正确，但不建议
		int age; //建议"英文的见名知意"
		int score,myScore,myJavaScore; //建议"驼峰命名法"
		*/
		
		/*
		//3.变量的使用:
		int a = 5;
		int b = a+10; //取出a的值5，加10后，再赋值给整型变量b
		System.out.println(b); //输出变量b的值15
		System.out.println("b"); //b，双引号中的原样输出
		a = a+10; //取出a的值5，加10后，再赋值给a
		          //在a本身基础之上增10
		System.out.println(a);
		
		//int c = 3.14; //编译错误，数据类型必须匹配
		
		//System.out.println(m); //编译错误，m未声明
		int m;
		//System.out.println(m); //编译错误，m未初始化
		*/
		
		/*
		//2.变量的初始化:第一次赋值
		int a = 250; //声明整型变量a并赋值为250
		int b;   //声明整型变量b
		b = 250; //给变量b赋值为250
		*/
		
		/*
		//1.变量的声明:
		int a; //声明一个整型的变量，名为a
		int b,c,d; //声明三个整型的变量，名为b,c,d
		*/
	}
}
















