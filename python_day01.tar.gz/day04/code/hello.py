
#　这是一个hello world程序
# 目的是让同学们了解python的执行顺序


print("hello world!")

# print("达内　你好！")

print(5)
print("2*3*4")
